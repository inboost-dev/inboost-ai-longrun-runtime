# InBoost LongRun Evaluation Runtime

[![Platform](https://img.shields.io/badge/platform-Linux%20%7C%20macOS%20%7C%20Windows-blue.svg)](#supported-platforms)
[![Architecture](https://img.shields.io/badge/arch-x86__64%20%7C%20ARM64-blue.svg)](#supported-platforms)
[![License](https://img.shields.io/badge/license-Evaluation%20License-orange.svg)](LICENSE_EVALUATION.md)
[![Privacy](https://img.shields.io/badge/privacy-100%25%20Local%20CPU-brightgreen.svg)](#privacy--data-security)
[![Tests](https://img.shields.io/badge/tests-11%20passed-brightgreen.svg)](#testing--verification)

> **Local context conservation and quota optimization runtime for AI coding assistants**  
> Compatible with **Claude Code**, **Google Antigravity (`agy`)**, **Cursor**, **Windsurf**, and **OpenHands**.

---

## 💡 Developer Advantages

Autonomous coding agents burn through token budgets and subscription rate limits rapidly when exploring codebases and debugging test suites. **InBoost LongRun** acts as a local intelligence filter, keeping your agent's context clean and focused.

* **Extended Rate-Limit Runway:** Work through longer, complex tasks without hitting hourly message caps or provider quota exhaustion walls.
* **Lower Token Burn & Costs:** Prevent agents from ingesting thousands of unnecessary tokens from full file dumps and massive test framework stack traces.
* **Faster Agent Response Times:** Leaner context windows significantly decrease time-to-first-token and overall turn latency.
* **Zero Wasted Repair Loops:** Local validation intercepts broken edits on your CPU before they are saved, saving 2–5 expensive roundtrips to fix trivial syntax errors.
* **Complete Privacy Guarantee:** 100% of processing happens on your local CPU. Your code and prompts never leave your workstation.

---

## 🚀 Quick Install

### Option 1: One-Line Installers (Linux / macOS / Windows)

**Linux & macOS:**
```bash
curl -fsSL https://raw.githubusercontent.com/inboost-dev/inboost-ai-longrun-runtime/main/install.sh | bash
```

**Windows (PowerShell):**
```powershell
irm https://raw.githubusercontent.com/inboost-dev/inboost-ai-longrun-runtime/main/install.ps1 | iex
```

### Option 2: Node.js (`npm` / `npx`)

```bash
# Run instantly with zero installation via npx:
npx inboost-longrun status
npx inboost-longrun serve

# Or install globally:
npm install -g inboost-longrun
```

### Option 3: Python (`pip`)

```bash
pip install inboost-longrun
inboost-longrun status
```

### Option 4: Local Repository Clone

```bash
git clone https://github.com/inboost-dev/inboost-ai-longrun-runtime.git
cd inboost-ai-longrun-runtime
./install.sh
```

---

## 🛠 Model Context Protocol (MCP) Tools

InBoost LongRun connects seamlessly to your editor or agent via the standard **Model Context Protocol (MCP)**, providing high-speed local tools designed to maximize context efficiency:

| Tool | Purpose & Developer Advantage |
| :--- | :--- |
| **`l0_view_outline`** | **Structural Code Inspection:** Gives your AI assistant a clear map of symbols, functions, and definitions without spending thousands of tokens reading full file bodies. |
| **`l0_clean_test_log`** | **Noise-Free Error Isolation:** Strips framework noise from test logs (pytest, unittest, jest) to expose the root-cause failure, preventing context pollution. |
| **`l0_verify_syntax`** | **Instant Syntax Guardrail:** Verifies code correctness on your local CPU before saving, preventing wasted prompt turns on syntax errors. |
| **`l0_verify_edit_scope`** | **Targeted Change Guardrail:** Keeps code modifications focused and within budget, stopping runaway diffs before they happen. |
| **`l0_run_test`** | **Compact Test Execution:** Runs local test suites and returns clean, signal-dense output tailored for agent decision-making. |
| **`l0_savings_report`** | **Savings & Quota Ledger:** Reports cumulative tokens conserved, quota windows extended, and syntax errors intercepted during your active session. |

---

## 🤖 AI Agent Setup

### 1. Claude Code

```bash
claude mcp add inboost-longrun -- inboost-longrun serve
```

Add optimization rules to `.claude/rules/inboost_longrun.md` (or `CLAUDE.md`):
```markdown
# InBoost LongRun Optimization Directives

1. Context Conservation: Before reading large files, use l0_view_outline to inspect declarations and structure.
2. Test Failure Isolation: Filter test logs and runtime exceptions via l0_clean_test_log to eliminate noise and isolate failing lines.
3. Syntax Integrity: Validate all code modifications with l0_verify_syntax prior to finalizing changes.
4. Edit Scope Compliance: Ensure edits remain focused and within budget. Verify with l0_verify_edit_scope.
5. Execution Optimization: Run test commands via l0_run_test for compact results. Check session economy with l0_savings_report.
```

### 2. Google Antigravity (`agy`)

```bash
agy mcp add inboost-longrun inboost-longrun serve
```

Rules are automatically loaded from `.agents/rules/inboost_longrun.md`.

### 3. Cursor

Add `inboost-longrun` to `.cursor/mcp.json`:
```json
{
  "mcpServers": {
    "inboost-longrun": {
      "command": "inboost-longrun",
      "args": ["serve"]
    }
  }
}
```

---

## 📦 Supported Platforms

All release binaries are standalone, statically compiled or native executables with zero external dependencies:

* **Linux:** `x86_64` & `arm64` (Universal Static ELF, zero libc dependencies)
* **macOS:** Apple Silicon (`arm64`, M1–M4) & Intel (`x86_64`) (Native Mach-O)
* **Windows:** `x86_64` (Native Console PE32+)

---

## 🔒 Privacy & Data Security

> **InBoost LongRun executes 100% locally on your machine and never transmits code externally.**

All analysis, verification, and filtering routines run exclusively on your workstation's CPU. The engine makes zero network connections, sends no telemetry, and requires no external API keys.

---

## 🧪 Testing & Verification

Run the automated test suite to verify binary integrity, license validity, and MCP protocol compliance:

```bash
./tests/run_tests.sh
```

---

## ⚖️ Evaluation License Terms

Usage of this distribution is subject to the [INBOOST LONGRUN EVALUATION LICENSE AGREEMENT](LICENSE_EVALUATION.md):
* **Evaluation Purpose Only:** Licensed exclusively for evaluation and non-production testing.
* **Term Limit:** Access is limited to the active evaluation period. Use must cease upon expiration.
* **Disclaimer:** Provided "AS IS" with no warranties; all liability is disclaimed to the maximum extent permitted by law.
* **Public Benchmarks:** Publication of benchmark results requires prior written consent from InBoost.
* **Jurisdiction:** InBoost reserves the right to determine the governing law and dispute resolution jurisdiction.
