# InBoost LongRun - Setup Guide for Claude Code

InBoost LongRun accelerates Claude Code by offloading repetitive code inspections, log parsing, and syntax verification to your laptop's local CPU.

### 1. Installation

Add InBoost LongRun to Claude Code via MCP:

```bash
claude mcp add inboost-longrun ./inboost-longrun
```

Verify status:
```bash
./inboost-longrun --status
```

### 2. Available Acceleration Tools

* `l0_view_outline`: Quickly inspect signatures and structure without downloading full file bodies.
* `l0_clean_test_log`: Filter verbose test logs and isolate root-cause failure lines.
* `l0_verify_syntax`: Validate code and diff syntax locally before proposing edits.
* `l0_verify_edit_scope`: Ensure edits remain focused and within safety guidelines.
* `l0_run_test`: Run tests locally on CPU; automatically filters noise if tests fail.
* `l0_savings_report`: View your cumulative session token and cost savings.

### 3. License

Included 1-Month Evaluation License is valid through November 11, 2026.
For renewals and support, contact support@inboost.dev.
