# InBoost LongRun - Setup Guide for Google Antigravity (agy)

### 1. Installation

Register InBoost LongRun as an MCP server:

```bash
agy mcp add inboost-longrun ./inboost-longrun
```

### 2. Activate Rules

Copy the acceleration rules into your workspace:

```bash
mkdir -p .agents/rules
cp inboost_rules.md .agents/rules/inboost_longrun.md
```
